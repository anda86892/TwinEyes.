import requests
import cv2
import numpy as np
import threading
import time
from datetime import datetime # เครื่องมือดึงเวลาจากคอมพิวเตอร์
from ultralytics import YOLO

# 1. ตั้งค่าพื้นฐาน
CAMERA_URL = "http://192.168.0.117/capture" # อย่าลืมแก้ IP
session = requests.Session()
print("Loading YOLO Model...")
model = YOLO("yolov8n.pt")

latest_frame = None
current_boxes = []
frame_lock = threading.Lock()

# 2. Thread 1: ผู้ผลิต (ดึงภาพ)
def fetch_camera_thread():
    global latest_frame
    while True:
        try:
            response = session.get(CAMERA_URL, timeout=5)
            if response.status_code == 200:
                image_array = np.array(bytearray(response.content), dtype=np.uint8)
                img = cv2.imdecode(image_array, -1)
                with frame_lock:
                    latest_frame = img.copy()
        except Exception as e:
            time.sleep(1)

# 3. Thread 2: ผู้บริโภค (AI ประมวลผล)
def ai_processing_thread():
    global latest_frame, current_boxes
    while True:
        frame_to_process = None
        with frame_lock:
            if latest_frame is not None:
                frame_to_process = latest_frame.copy()
        
        if frame_to_process is not None:
            results = model(frame_to_process, stream=True, verbose=False)
            temp_boxes = []
            for r in results:
                for box in r.boxes:
                    if int(box.cls[0]) == 0:
                        # ดึงพิกัด (x,y)
                        xyxy = box.xyxy[0].tolist()
                        # ดึงค่า % ความมั่นใจ (Confidence Score) ออกมาเป็นตัวเลขทศนิยม
                        conf = float(box.conf[0]) 
                        
                        # เก็บค่าทั้งพิกัดและเปอร์เซ็นต์ไว้ในถังข้อมูล
                        temp_boxes.append((xyxy, conf))
            current_boxes = temp_boxes
        else:
            time.sleep(0.01)

# 4. ฟังก์ชันหลัก: วาดภาพและจัดการโหมดเวลา
if __name__ == "__main__":
    t1 = threading.Thread(target=fetch_camera_thread, daemon=True)
    t2 = threading.Thread(target=ai_processing_thread, daemon=True)
    t1.start()
    t2.start()

    while True:
        display_frame = None
        with frame_lock:
            if latest_frame is not None:
                display_frame = latest_frame.copy()

        if display_frame is not None:
            # --- กลไก: Context-Aware Adaptive Thresholding ---
            
            # เช็คชั่วโมงปัจจุบัน (0 - 23)
            current_hour = datetime.now().hour
            
            # กำหนดกลางวันคือ 06:00 ถึง 17:59
            is_daytime = 6 <= current_hour < 18 
            
            # สลับโหมดและตั้ง Threshold 
            current_threshold = 0.60 if is_daytime else 0.30
            mode_text = "DAY MODE (Th: 60%)" if is_daytime else "NIGHT MODE (Th: 30%)"

            # พิมพ์โหมดปัจจุบันแปะไว้ที่มุมซ้ายบนของจอ
            cv2.putText(display_frame, mode_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

            # วนลูปวาดกล่องเฉพาะตัวที่ "ผ่านเกณฑ์ Threshold" ที่ตั้งไว้
            for box_data in current_boxes:
                xyxy, conf = box_data
                
                # ถ้ามั่นใจมากกว่าหรือเท่ากับเกณฑ์ปัจจุบัน ถึงจะวาดกล่อง
                if conf >= current_threshold:
                    x1, y1, x2, y2 = map(int, xyxy)
                    
                    # แปลงทศนิยมเป็นเปอร์เซ็นต์ เช่น 0.85 -> 85%
                    label = f"Person {int(conf*100)}%"
                    
                    cv2.rectangle(display_frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(display_frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

            cv2.imshow("TwinEyes AI stream", display_frame)

        if cv2.waitKey(10) & 0xFF == ord('q'):
            break

    cv2.destroyAllWindows()