#include <Arduino.h>
#include <esp_camera.h>
#include <WiFi.h>
#include <esp_http_server.h>
#define PWDN_GPIO_NUM -1
#define RESET_GPIO_NUM -1
#define XCLK_GPIO_NUM 14
#define SIOC_GPIO_NUM 5
#define Y8_GPIO_NUM 16
#define Y6_GPIO_NUM 12
#define Y4_GPIO_NUM 8
#define Y2_GPIO_NUM 11
#define HREF_GPIO_NUM 7
#define SIOD_GPIO_NUM 4
#define Y9_GPIO_NUM 15
#define Y7_GPIO_NUM 17
#define Y5_GPIO_NUM 10
#define Y3_GPIO_NUM 9
#define VSYNC_GPIO_NUM 6
#define PCLK_GPIO_NUM 13

const char* ssid = "@Bayan n54822";     // ใส่ชื่อ WiFi
const char* password = "n548229188"; // ใส่รหัส WiFi

void startCameraServer();

void setup() {
  Serial.begin(115200);
  delay(3000);
  Serial.println("-------------------------------");
  Serial.println("SYSTEM STARTING...");
  Serial.println("-------------------------------");
  // 2. Config กล้อง
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;
  config.frame_size = FRAMESIZE_VGA; // 640x480
  config.jpeg_quality = 12;
  config.fb_count = 1;

  // 3. Init กล้อง
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed with error 0x%x", err);
    return;
  }

  // 4. เชื่อมต่อ WiFi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.println("WiFi connected");
  
  // 5. เริ่ม Server
  startCameraServer();
  
  Serial.print("Camera Ready! Use 'http://");
  Serial.print(WiFi.localIP());
  Serial.println("/capture' to connect");
}

void loop() {
  Serial.println("Hello im alive");
  delay(1000);
}

// ส่วนของ HTTP Handler
esp_err_t capture_handler(httpd_req_t *req) {
  camera_fb_t * fb = NULL;
  fb = esp_camera_fb_get();
  if (!fb) {
    Serial.println("Camera capture failed");
    httpd_resp_send_500(req);
    return ESP_FAIL;
  }
  httpd_resp_set_type(req, "image/jpeg");
  httpd_resp_set_hdr(req, "Content-Disposition", "inline; filename=capture.jpg");
  esp_err_t res = httpd_resp_send(req, (const char *)fb->buf, fb->len);
  esp_camera_fb_return(fb);
  return res;
}

void startCameraServer() {
  httpd_config_t config = HTTPD_DEFAULT_CONFIG();
  httpd_handle_t stream_httpd = NULL;
  if (httpd_start(&stream_httpd, &config) == ESP_OK) {
    httpd_uri_t capture_uri = {
      .uri       = "/capture",
      .method    = HTTP_GET,
      .handler   = capture_handler,
      .user_ctx  = NULL
    };
    httpd_register_uri_handler(stream_httpd, &capture_uri);
  }
}